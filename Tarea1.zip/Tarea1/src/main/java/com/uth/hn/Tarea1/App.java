package com.uth.hn.Tarea1;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner lee = new Scanner(System.in);
        boolean continuar = true; 

        while (continuar) {
            System.out.println("1 = CALCULAR EL ÁREA DE UN CÍRCULO");
            System.out.println("2 = CALCULAR EL ÁREA DE UN CUADRADO");
            System.out.println("3 = CALCULAR EL ÁREA DE UN RECTÁNGULO");
            System.out.println("4 = CALCULAR EL ÁREA DE UN TRIÁNGULO");
            System.out.println("5 = SALIR");
            System.out.print("ELIJE QUÉ DESEAS CALCULAR Y SELECCIONA LA OPCIÓN CORRESPONDIENTE: ");
            int opcion = lee.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el radio del círculo: ");
                    double radio = lee.nextDouble();

                    double cArea = calculoAreaCirculo(radio);
                    System.out.println("El área del círculo es: " + cArea);
                    break;

                case 2:
                    System.out.print("Ingrese el lado del cuadrado: ");
                    double lado = lee.nextDouble();

                    double cuArea = calculoAreaCuadrado(lado);
                    System.out.println("El área del cuadrado es: " + cuArea);
                    break;

                case 3:
                    System.out.print("Ingrese el largo del rectángulo: ");
                    double largo = lee.nextDouble();
                    System.out.print("Ingrese el ancho del rectángulo: ");
                    double ancho = lee.nextDouble();

                    double rArea = calculoAreaRectangulo(largo, ancho);
                    System.out.println("El área del rectángulo es: " + rArea);
                    break;

                case 4:
                    System.out.print("Ingrese la base del triángulo: ");
                    double base = lee.nextDouble();
                    System.out.print("Ingrese la altura del triángulo: ");
                    double altura = lee.nextDouble();

                    double tArea = calculoAreaTriangulo(base, altura);
                    System.out.println("El área del triángulo es: " + tArea);
                    break;

                case 5:
                    System.out.println("Saliendo del programa...");
                    continuar = false; // Cambia la variable para salir del ciclo
                    break;

                default:
                    System.out.println("Opción no válida");
            }
        }

        lee.close();
    }

    // Métodos para los cálculos
    public static double calculoAreaCirculo(double radio) {
        double areaCirculo = 3.14159 * (radio * radio);
        return areaCirculo;
    }

    public static double calculoAreaCuadrado(double lado) {
        double areaCuadrado = lado * lado;
        return areaCuadrado;
    }

    public static double calculoAreaRectangulo(double largo, double ancho) {
        double areaRectangulo = largo * ancho;
        return areaRectangulo;
    }

    public static double calculoAreaTriangulo(double base, double altura) {
        double areaTriangulo = (base * altura) / 2;
        return areaTriangulo;
    }
}
