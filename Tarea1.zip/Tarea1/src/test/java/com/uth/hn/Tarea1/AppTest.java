package com.uth.hn.Tarea1;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AppTest {
    
    @Before
    public void setupClass1() {
        System.out.println("Ejecutando metodo tipo Setup antes de cada test...");
    }
    
    @BeforeClass
    public static void setupClass2() {
        App Aplicacion = new App();
        Aplicacion.main(null);
    }

    // Pruebas para el cálculo del área del círculo
    @Test
    public void testCalculoAreaCirculo1() {
        assertEquals(App.calculoAreaCirculo(5.0), 78.54, 0.01);
    }

    @Test
    public void testCalculoAreaCirculo2() {
        assertEquals(App.calculoAreaCirculo(0.0), 0.0, 0.01);
    }

    @Test
    public void testCalculoAreaCirculo3() {
        assertEquals(App.calculoAreaCirculo(10.0), 314.16, 0.01);
    }

    @Test
    public void testCalculoAreaCirculo4() {
        assertEquals(App.calculoAreaCirculo(-5.0), 78.54, 0.01);
    }

    // Pruebas para el cálculo del área del cuadrado
    @Test
    public void testCalculoAreaCuadrado1() {
        assertEquals(App.calculoAreaCuadrado(6.0), 36.0, 0.01);
    }

    @Test
    public void testCalculoAreaCuadrado2() {
        assertEquals(App.calculoAreaCuadrado(0.0), 0.0, 0.01);
    }

    @Test
    public void testCalculoAreaCuadrado3() {
        assertEquals(App.calculoAreaCuadrado(7.5), 56.25, 0.01);
    }

    @Test
    public void testCalculoAreaCuadrado4() {
        assertEquals(App.calculoAreaCuadrado(-4.0), 16.0, 0.01);
    }

    // Pruebas para el cálculo del área del rectángulo
    @Test
    public void testCalculoAreaRectangulo1() {
        assertEquals(App.calculoAreaRectangulo(10.0, 5.0), 50.0, 0.01);
    }

    @Test
    public void testCalculoAreaRectangulo2() {
        assertEquals(App.calculoAreaRectangulo(0.0, 7.0), 0.0, 0.01);
    }

    @Test
    public void testCalculoAreaRectangulo3() {
        assertEquals(App.calculoAreaRectangulo(8.0, 8.0), 64.0, 0.01);
    }

    // Pruebas para el cálculo del área del triángulo
    @Test
    public void testCalculoAreaTriangulo1() {
        assertEquals(App.calculoAreaTriangulo(8.0, 6.0), 24.0, 0.01);
    }

    @Test
    public void testCalculoAreaTriangulo2() {
        assertEquals(App.calculoAreaTriangulo(0.0, 5.0), 0.0, 0.01);
    }

    @Test
    public void testCalculoAreaTriangulo3() {
        assertEquals(App.calculoAreaTriangulo(12.0, 10.0), 60.0, 0.01);
    }

    @Test
    public void testCalculoAreaTriangulo4() {
        assertEquals(App.calculoAreaTriangulo(8.0, -6.0), -24.0, 0.01);
    }
    
    //Pruebas de tipo TearDown

}